<?php 
print "[ Aplikasi check No.KTP & KK ]\n\n";
 print "Link download nya : https://goo.gl/vqbvtA\n\n";
print "Thanks To: BabbyCyberTeam || SGB-TEAM || JNCK MEDIA || And You\n";
?>
